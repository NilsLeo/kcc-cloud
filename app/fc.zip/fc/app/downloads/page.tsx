"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, RefreshCw, ChevronLeft, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { Logo } from "@/components/logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { Navbar } from "@/components/navbar"
import { useConverterMode } from "@/contexts/converter-mode-context"
import mockData from "@/lib/mock-data.json"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileConversionCard } from "@/components/file-conversion-card"

type UserDownload = {
  job_id: string
  original_filename: string
  converted_filename: string
  device_profile: string
  input_file_size?: number
  output_file_size?: number
  completed_at?: string
  actual_duration?: number
  download_url?: string
  status: string
  progress: number
}

export default function DownloadsPage() {
  const { mode } = useConverterMode()
  const themeClass = mode === "manga" ? "manga-theme" : "comic-theme"
  // Demo mode is opt-in; default to false unless explicitly set
  const demoMode = process.env.NEXT_PUBLIC_DEMO_MODE === "true"

  const [downloads, setDownloads] = useState<UserDownload[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [downloadingFiles, setDownloadingFiles] = useState<Record<string, boolean>>({})
  const [totalCount, setTotalCount] = useState(0)
  const [usingMockData, setUsingMockData] = useState(false)
  const [refreshing, setRefreshing] = useState(false)

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(5)

  useEffect(() => {
    fetchDownloads()
  }, [])

  const fetchDownloads = async () => {
    try {
      setLoading(true)
      setError(null)
      setRefreshing(true)

      const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8060"

      try {
        console.log("[v0] Attempting to fetch from localhost:8060...")
        const response = await fetch(`${API_BASE_URL}/downloads?limit=1000&include_dismissed=true`, {
          signal: AbortSignal.timeout(3000),
        })

        if (!response.ok) {
          throw new Error(`API returned ${response.status}`)
        }

        const data = await response.json()
        const downloadsData = (data.downloads || []).map((download: any) => ({
          job_id: download.job_id,
          original_filename: download.original_filename,
          converted_filename: download.converted_filename,
          device_profile: download.device_profile,
          input_file_size: download.input_file_size,
          output_file_size: download.output_file_size,
          completed_at: download.completed_at,
          actual_duration: download.actual_duration,
          download_url: `${API_BASE_URL}${download.download_url}`,
          status: download.status || "COMPLETE",
          progress: download.progress || 100,
        }))

        console.log("[v0] Successfully fetched from localhost:8060", { count: downloadsData.length })
        setDownloads(downloadsData)
        setTotalCount(data.total || downloadsData.length)
        setUsingMockData(false)
      } catch (apiError) {
        if (!demoMode) throw apiError
        console.log("[v0] API not reachable, using mock data (demo mode)", {
          error: apiError instanceof Error ? apiError.message : String(apiError),
        })

        await new Promise((resolve) => setTimeout(resolve, 300))
        setDownloads(mockData.myDownloads as UserDownload[])
        setTotalCount(mockData.myDownloads.length)
        setUsingMockData(true)
      }
    } catch (error) {
      console.error("[DownloadsPage] Error fetching downloads:", error)
      setError(error instanceof Error ? error.message : "Failed to load downloads")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const handleDownload = async (download: UserDownload) => {
    try {
      setDownloadingFiles((prev) => ({ ...prev, [download.job_id]: true }))

      if (usingMockData) {
        await new Promise((resolve) => setTimeout(resolve, 1500))
        toast.success(`Mock download: ${download.converted_filename}`)
        setDownloadingFiles((prev) => ({ ...prev, [download.job_id]: false }))
        return
      }

      const response = await fetch(download.download_url!)
      if (!response.ok) {
        throw new Error(`Download failed: ${response.status}`)
      }

      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = download.converted_filename || `converted_${download.original_filename}`
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
      document.body.removeChild(a)

      toast.success(`Downloaded: ${download.converted_filename}`)
    } catch (error) {
      console.error("[DownloadsPage] Download error:", error)
      toast.error("Failed to download file", {
        description: error instanceof Error ? error.message : "Unknown error",
      })
    } finally {
      setDownloadingFiles((prev) => ({ ...prev, [download.job_id]: false }))
    }
  }

  const handleDelete = async (download: UserDownload) => {
    if (usingMockData && demoMode) {
      toast.info(`Delete clicked for ${download.converted_filename}`)
      return
    }

    try {
      const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8060"
      const res = await fetch(`${API_BASE_URL}/downloads/${download.job_id}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || `Delete failed (${res.status})`)
      }
      // Remove from local state
      setDownloads((prev) => prev.filter((d) => d.job_id !== download.job_id))
      setTotalCount((c) => Math.max(0, c - 1))
      toast.success(`Deleted ${download.converted_filename || download.original_filename}`)
    } catch (e) {
      toast.error("Failed to delete download", { description: e instanceof Error ? e.message : String(e) })
    }
  }

  // Pagination logic
  const totalPages = Math.ceil(totalCount / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedDownloads = downloads.slice(startIndex, endIndex)

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)))
  }

  const handleItemsPerPageChange = (value: string) => {
    setItemsPerPage(Number(value))
    setCurrentPage(1) // Reset to first page when changing items per page
  }

  if (loading) {
    return (
      <div className={`min-h-screen bg-background flex flex-col ${themeClass}`}>
        <header className="border-b sticky top-0 z-50 bg-background">
          <div className="container mx-auto px-4 py-4 md:py-5 flex justify-between items-center">
            <Logo />
            <div className="flex items-center gap-4">
              <Navbar />
              <ThemeToggle />
            </div>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <CardTitle>My Downloads</CardTitle>
              <CardDescription>Loading your converted files...</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                  <Skeleton className="h-9 w-24" />
                </div>
              ))}
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  if (error) {
    return (
      <div className={`min-h-screen bg-background flex flex-col ${themeClass}`}>
        <header className="border-b sticky top-0 z-50 bg-background">
          <div className="container mx-auto px-4 py-4 md:py-5 flex justify-between items-center">
            <Logo />
            <div className="flex items-center gap-4">
              <Navbar />
              <ThemeToggle />
            </div>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <CardTitle>My Downloads</CardTitle>
            </CardHeader>
            <CardContent>
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
              <Button onClick={fetchDownloads} className="mt-4 bg-transparent" variant="outline">
                Try Again
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  if (downloads.length === 0) {
    return (
      <div className={`min-h-screen bg-background flex flex-col ${themeClass}`}>
        <header className="border-b sticky top-0 z-50 bg-background">
          <div className="container mx-auto px-4 py-4 md:py-5 flex justify-between items-center">
            <Logo />
            <div className="flex items-center gap-4">
              <Navbar />
              <ThemeToggle />
            </div>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-8">
          <Card>
            <CardHeader>
              <CardTitle>My Downloads</CardTitle>
              <CardDescription>No completed conversions yet</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Convert some files to see them here!</p>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-background flex flex-col ${themeClass}`}>
      <header className="border-b sticky top-0 z-50 bg-background">
        <div className="container mx-auto px-4 py-4 md:py-5 flex justify-between items-center">
          <Logo />
          <div className="flex items-center gap-4">
            <Navbar />
            <ThemeToggle />
          </div>
        </div>
      </header>
      <main className="flex-1 container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>My Downloads</CardTitle>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  if (refreshing) {
                    toast.info("Please wait", {
                      description: "Downloads are currently being refreshed.",
                    })
                    return
                  }
                  fetchDownloads()
                }}
                disabled={refreshing}
                aria-label="Refresh downloads list"
                className="h-8 w-8 shrink-0"
              >
                <RefreshCw className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`} />
              </Button>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <CardDescription>
                {totalCount} completed conversion{totalCount !== 1 ? "s" : ""}
                {usingMockData && demoMode && (
                  <Badge variant="outline" className="ml-2 text-xs">
                    Demo Mode
                  </Badge>
                )}
              </CardDescription>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Show:</span>
                <Select value={itemsPerPage.toString()} onValueChange={handleItemsPerPageChange}>
                  <SelectTrigger className="w-[80px] h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5</SelectItem>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <AnimatePresence mode="popLayout">
                {paginatedDownloads.map((download) => {
                  const fileData = {
                    id: download.job_id,
                    jobId: download.job_id,
                    name: download.converted_filename || download.original_filename,
                    size: download.output_file_size || download.input_file_size,
                    status: download.status,
                    upload_progress: download.status === "UPLOADING" ? { percentage: download.progress } : undefined,
                    processing_progress:
                      download.status === "PROCESSING"
                        ? { progress_percent: download.progress, elapsed_seconds: 0, remaining_seconds: 0 }
                        : undefined,
                    error: download.status === "ERROR" ? "Conversion failed" : undefined,
                    isConverted: download.status === "COMPLETE",
                    device_profile: download.device_profile,
                  }

                  return (
                    <motion.div
                      key={download.job_id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -100 }}
                    >
                      <FileConversionCard
                        file={fileData}
                        onDownload={() => handleDownload(download)}
                        onDelete={() => handleDelete(download)}
                        showActions={true}
                        isDownloading={downloadingFiles[download.job_id]}
                      />
                    </motion.div>
                  )
                })}
              </AnimatePresence>
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6 pt-4 border-t">
                <div className="text-sm text-muted-foreground">
                  Showing {startIndex + 1}-{Math.min(endIndex, totalCount)} of {totalCount}
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (currentPage === 1) {
                        toast.info("Already at first page", {
                          description: "You're viewing the first page of downloads.",
                        })
                        return
                      }
                      goToPage(currentPage - 1)
                    }}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4 mr-1" />
                    Previous
                  </Button>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNum
                      if (totalPages <= 5) {
                        pageNum = i + 1
                      } else if (currentPage <= 3) {
                        pageNum = i + 1
                      } else if (currentPage >= totalPages - 2) {
                        pageNum = totalPages - 4 + i
                      } else {
                        pageNum = currentPage - 2 + i
                      }

                      return (
                        <Button
                          key={pageNum}
                          variant={currentPage === pageNum ? "default" : "outline"}
                          size="sm"
                          onClick={() => goToPage(pageNum)}
                          className="w-9 h-9 p-0"
                        >
                          {pageNum}
                        </Button>
                      )
                    })}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      if (currentPage === totalPages) {
                        toast.info("Already at last page", {
                          description: "You're viewing the last page of downloads.",
                        })
                        return
                      }
                      goToPage(currentPage + 1)
                    }}
                    disabled={currentPage === totalPages}
                  >
                    Next
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
